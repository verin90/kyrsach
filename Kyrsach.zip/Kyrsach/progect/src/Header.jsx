import { useState } from 'react'
import './Header.module.css'
import logo  from './assets/logo.png'
import telefon  from './assets/telefon.png'

function Header() {
  const [count, setCount] = useState(0)

  return (
    <>
      <header>
        <ul className='head_top'>
            <img src={logo} alt="" /> 
            <ul className='referens'>
              <a href="">Проекты</a>
              <a href="">О нас</a>
              <a href="">Услуги</a>
              <a href="">Цены</a>
              <a href="">Статьи</a>
              <a href="">Вакансии</a>
              <a href="">онтакты</a>  
            </ul>
            <ul className='tel'>
              <img src={telefon} alt="" />
              <li>+7 (495) 755-02-29</li>
            </ul>  
        </ul>
        <ul className='head_bottom'>

        </ul>
      </header>
    </>
  )
}

export default Header