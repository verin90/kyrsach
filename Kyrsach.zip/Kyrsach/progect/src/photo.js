import logo from './assets/logo.png'
import telefon from './assets/telefon.png'

export const Photo ={
    logo:logo,
    telefon:telefon,
    
}